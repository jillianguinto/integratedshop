
		<script src="<?php echo base_url()?>template/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url()?>template/js/plugins/morris/raphael.min.js"></script>
		<script src="<?php echo base_url()?>template/js/plugins/morris/morris.min.js"></script>
		<script src="<?php echo base_url()?>template/js/plugins/morris/morris-data.js"></script>
		<!--script src="<?php echo base_url()?>template/js/jssignin.js"></script-->

	<body>
</html>
