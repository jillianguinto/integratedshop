<style>
	.img-rows{
		text-align: center;	
	}
	.store-menu img{
		width: 60%;
		cursor: pointer;
	}
	.store-label{
		text-align: center;

	}
	#menu-container{
		display: none;
	}

</style>
<div class="store-label col-md-12">
	<h3>Select Storee</h3>
</div>
<div class="store-menu">
	<div class="col-md-12">
		<div class="row img-rows">
			<div class="col-md-4">

				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(1)" >
				Clickhealth
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(2)" >
				Evolife
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(3)" >
				Celeteque
			</div>
		</div>
		<div class="row img-rows">
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(4)">
				Clickhealthplus
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(5)">
				celeteq
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(12)">
				Unilab Active Health
			</div>
		</div>
		<div class="row img-rows">
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(13)">
				Family Health at Home
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(15)">
				GutHealth
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(16)">
				Liviacor
			</div>
		</div>
		<div class="row img-rows">
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(17)">
				Athena
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(18)">
				Conzace
			</div>
			<div class="col-md-4">
				<img src="<?php echo base_url()?>template/images/celeteq.png" class="img-responsive" alt="Image" onclick="connectdb2(19)">
				Ritemed
			</div>
		</div>
	</div>
</div>

