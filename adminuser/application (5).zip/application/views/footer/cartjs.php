	<!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
	<script src="<?php echo base_url()?>template/js/plugins/flot/jquery.flot.js"></script>
	<script src="<?php echo base_url()?>template/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
	<script src="<?php echo base_url()?>template/js/plugins/flot/jquery.flot.resize.js"></script>
	<script src="<?php echo base_url()?>template/js/plugins/flot/jquery.flot.pie.js"></script>
	<script src="<?php echo base_url()?>template/js/plugins/flot/flot-data.js"></script>