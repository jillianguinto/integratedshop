jQuery(document).ready(function (){
	
	jQuery(".close_me").click(function (){
		jQuery("#popup-product").fadeOut();
	});
	
});